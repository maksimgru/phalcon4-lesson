-- Adminer 4.7.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1,	'admin',	'Administrator - can do everything'),
(2,	'guest',	'Anyone browsing the site who is not signed in is considered to be a \"Guest\".'),
(3,	'user',	'Registered User privileges, granted after sign in.');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` char(60) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `role_id` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `active`, `role_id`, `created_at`, `updated_at`) VALUES
(1,	'Admin Power',	'admin@example.com',	'$2y$10$TzFGeEVybGZBWnIxNEQ2NeZvtf.G9k91PiDgUuqyF6BMdZc9S.16m',	1,	1,	'2020-04-27 21:21:32',	'2020-04-27 21:21:32'),
(2,	'Simple User',	'user@example.com',	'$2y$10$UjVuN2tTaHcrNGJobEowYeULGTs1Qu8ovRm3gCPCWZC38UjkEztVW',	1,	3,	'2020-04-27 21:22:34',	'2020-04-27 21:22:34');

-- 2020-04-27 21:25:01
